'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import { ChevronLeft, ChevronRight, Sun, Moon, AlertTriangle } from 'lucide-react'
import api from '@/lib/api'

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December']
const DAY_ABBR = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']

function fmtDate(year, month, day) {
  return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
}

function nextDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00')
  d.setDate(d.getDate() + 1)
  return fmtDate(d.getFullYear(), d.getMonth(), d.getDate())
}

function slotKey(date, slot) { return `${date}:${slot}` }

function cmpSlot(a, b) {
  if (a.date < b.date) return -1
  if (a.date > b.date) return 1
  return (a.slot === 'day' ? 0 : 1) - (b.slot === 'day' ? 0 : 1)
}

function buildRange(from, to, isDayOnly) {
  if (!from) return []
  const end = to || from
  const slots = []
  let d = from.date, s = from.slot
  for (let i = 0; i < 500; i++) {
    if (cmpSlot({ date: d, slot: s }, end) > 0) break
    slots.push({ date: d, slot: s })
    if (s === 'day' && !isDayOnly) s = 'night'
    else { d = nextDate(d); s = 'day' }
  }
  return slots
}

function buildOvernightRange(checkInDate, checkOutDate, slotType = 'overnight') {
  if (!checkInDate) return []
  const end = checkOutDate || checkInDate
  const slots = []
  let d = checkInDate
  for (let i = 0; i < 500; i++) {
    if (d >= end) break
    slots.push({ date: d, slot: slotType })
    d = nextDate(d)
  }
  if (slots.length === 0 && checkInDate && !checkOutDate) {
    slots.push({ date: checkInDate, slot: slotType })
  }
  return slots
}

function labelSlot(s) {
  if (!s) return ''
  const d = new Date(s.date + 'T00:00:00')
  if (s.slot === 'overnight') {
    return `${MONTHS[d.getMonth()].slice(0, 3)} ${d.getDate()}`
  }
  if (s.slot === '24hr') {
    return `${MONTHS[d.getMonth()].slice(0, 3)} ${d.getDate()} (24hr)`
  }
  return `${MONTHS[d.getMonth()].slice(0, 3)} ${d.getDate()} (${s.slot === 'day' ? 'Day' : 'Night'})`
}

function formatCheckOutDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00')
  d.setDate(d.getDate() + 1)
  return `${MONTHS[d.getMonth()].slice(0, 3)} ${d.getDate()}`
}

export default function SlotPicker({ roomId, isDayOnly, bookingMode, onSlotsChange, onRangeChange, defaultCheckIn, defaultCheckOut, allowPastDates, weekendDisabled }) {
  const isOvernight = bookingMode === 'overnight' || bookingMode === '24hr'
  const [bookedSlots, setBookedSlots] = useState([])
  const [maxRooms, setMaxRooms] = useState(1)
  const [loading, setLoading] = useState(true)

  const [checkIn, setCheckIn] = useState(defaultCheckIn || null)
  const [checkOut, setCheckOut] = useState(defaultCheckOut || null)

  const [overnightCheckIn, setOvernightCheckIn] = useState(
    defaultCheckIn?.date || (typeof defaultCheckIn === 'string' ? defaultCheckIn : null)
  )
  const [overnightCheckOut, setOvernightCheckOut] = useState(
    defaultCheckOut?.date || (typeof defaultCheckOut === 'string' ? defaultCheckOut : null)
  )

  const now = new Date()
  const curHour = now.getHours()
  const todayStr = fmtDate(now.getFullYear(), now.getMonth(), now.getDate())
  const [viewYear, setViewYear] = useState(now.getFullYear())
  const [viewMonth, setViewMonth] = useState(now.getMonth())

  useEffect(() => {
    ;(async () => {
      try {
        const { data } = await api.get(`/rooms/${roomId}/availability/`)
        setBookedSlots(data.booked_slots || [])
        setMaxRooms(data.max_rooms || 1)
      } catch (err) { console.error('Failed to load availability:', err) }
      finally { setLoading(false) }
    })()
  }, [roomId])

  const bookedCounts = useMemo(() => {
    const counts = {}
    for (const x of bookedSlots) {
      const key = slotKey(x.date, x.slot)
      counts[key] = (counts[key] || 0) + 1
    }
    return counts
  }, [bookedSlots])

  const isBooked  = useCallback((d, s) => (bookedCounts[slotKey(d, s)] || 0) >= maxRooms, [bookedCounts, maxRooms])

  const yesterdayStr = useMemo(() => {
    const y = new Date(now)
    y.setDate(y.getDate() - 1)
    return fmtDate(y.getFullYear(), y.getMonth(), y.getDate())
  }, [])

  const isSlotPast = useCallback((dateStr, slot) => {
    if (allowPastDates) return dateStr >= todayStr
    if (dateStr < todayStr) return true
    if (dateStr === todayStr && slot === 'day' && curHour >= 17) return true
    if (weekendDisabled) {
      const d = new Date(dateStr + 'T00:00:00')
      if (d.getDay() === 0 || d.getDay() === 6) return true
    }
    return false
  }, [todayStr, curHour, allowPastDates, weekendDisabled])

  const overnightSlotType = bookingMode === '24hr' ? '24hr' : 'overnight'
  const overnightSlots = useMemo(() => {
    if (!isOvernight) return []
    return buildOvernightRange(overnightCheckIn, overnightCheckOut, overnightSlotType)
  }, [isOvernight, overnightCheckIn, overnightCheckOut, overnightSlotType])

  const overnightSelectedDates = useMemo(() => {
    return new Set(overnightSlots.map(s => s.date))
  }, [overnightSlots])

  const overnightOverlaps = useMemo(() => {
    if (!isOvernight) return []
    return overnightSlots.filter(s => isBooked(s.date, overnightSlotType))
  }, [isOvernight, overnightSlots, overnightSlotType, bookedCounts, maxRooms])

  const overnightHasOverlap = overnightOverlaps.length > 0

  const overnightFinalSlots = useMemo(() => {
    if (overnightHasOverlap) return []
    return overnightSlots
  }, [overnightSlots, overnightHasOverlap])

  const overnightNights = overnightFinalSlots.length

  const handleOvernightDateClick = useCallback((dateStr) => {
    if (isBooked(dateStr, overnightSlotType) || isSlotPast(dateStr, overnightSlotType)) return

    if (!overnightCheckIn || overnightCheckOut) {
      setOvernightCheckIn(dateStr)
      setOvernightCheckOut(null)
    } else {
      if (dateStr > overnightCheckIn) {
        setOvernightCheckOut(dateStr)
      } else if (dateStr === overnightCheckIn) {
        setOvernightCheckIn(null)
        setOvernightCheckOut(null)
      } else {
        setOvernightCheckIn(dateStr)
        setOvernightCheckOut(null)
      }
    }
  }, [overnightCheckIn, overnightCheckOut, overnightSlotType, isBooked, isSlotPast])

  useEffect(() => {
    if (isOvernight) {
      onSlotsChange?.(overnightFinalSlots)
    }
  }, [isOvernight, overnightFinalSlots])

  useEffect(() => {
    if (isOvernight) {
      onRangeChange?.(
        overnightCheckIn ? { date: overnightCheckIn, slot: overnightSlotType } : null,
        overnightCheckOut ? { date: overnightCheckOut, slot: overnightSlotType } : null
      )
    }
  }, [isOvernight, overnightCheckIn, overnightCheckOut])

  const earliestSlot = useCallback((dateStr) => {
    if (isDayOnly) return 'day'
    if (!isSlotPast(dateStr, 'day') && !isBooked(dateStr, 'day')) return 'day'
    if (!isSlotPast(dateStr, 'night') && !isBooked(dateStr, 'night')) return 'night'
    return null
  }, [isDayOnly, isSlotPast, isBooked])

  const latestSlot = useCallback((dateStr) => {
    if (isDayOnly) return 'day'
    if (!isSlotPast(dateStr, 'night') && !isBooked(dateStr, 'night')) return 'night'
    if (!isSlotPast(dateStr, 'day') && !isBooked(dateStr, 'day')) return 'day'
    return null
  }, [isDayOnly, isSlotPast, isBooked])

  const rangeSlots = useMemo(() => {
    if (isOvernight) return []
    return buildRange(checkIn, checkOut, isDayOnly)
  }, [isOvernight, checkIn, checkOut, isDayOnly])
  const rangeSet   = useMemo(() => new Set(rangeSlots.map(s => slotKey(s.date, s.slot))), [rangeSlots])

  const overlaps = useMemo(() => rangeSlots.filter(s => isBooked(s.date, s.slot)), [rangeSlots, bookedCounts, maxRooms])
  const hasOverlap = overlaps.length > 0

  const selectedSlots = useMemo(() => {
    if (hasOverlap) return []
    return rangeSlots
  }, [rangeSlots, hasOverlap])

  const selectedSet = useMemo(() => new Set(selectedSlots.map(s => slotKey(s.date, s.slot))), [selectedSlots])

  useEffect(() => { if (!isOvernight) onSlotsChange?.(selectedSlots) }, [isOvernight, selectedSlots])
  useEffect(() => { if (!isOvernight) onRangeChange?.(checkIn, checkOut) }, [isOvernight, checkIn, checkOut])

  const applySelection = useCallback((clicked) => {
    if (!checkIn || checkOut) {
      setCheckIn(clicked)
      setCheckOut(null)
    } else {
      if (cmpSlot(clicked, checkIn) > 0) {
        setCheckOut(clicked)
      } else {
        setCheckIn(clicked)
        setCheckOut(null)
      }
    }
  }, [checkIn, checkOut])

  const handleSlotClick = useCallback((dateStr, slot) => {
    if (isBooked(dateStr, slot) || isSlotPast(dateStr, slot)) return
    applySelection({ date: dateStr, slot })
  }, [isBooked, isSlotPast, applySelection])

  const handleDateClick = useCallback((dateStr) => {
    if (!checkIn || checkOut) {
      const slot = earliestSlot(dateStr)
      if (!slot) return
      setCheckIn({ date: dateStr, slot })
      setCheckOut(null)
    } else {
      const clicked = { date: dateStr, slot: latestSlot(dateStr) || 'day' }
      if (cmpSlot(clicked, checkIn) > 0) {
        setCheckOut(clicked)
      } else if (dateStr === checkIn.date) {
        const slot = earliestSlot(dateStr)
        if (!slot) return
        setCheckIn({ date: dateStr, slot })
        setCheckOut(null)
      } else {
        const slot = earliestSlot(dateStr)
        if (!slot) return
        setCheckIn({ date: dateStr, slot })
        setCheckOut(null)
      }
    }
  }, [checkIn, checkOut, earliestSlot, latestSlot])

  const prevMonth = () => { if (viewMonth === 0) { setViewMonth(11); setViewYear(v => v - 1) } else setViewMonth(m => m - 1) }
  const nextMonth = () => { if (viewMonth === 11) { setViewMonth(0); setViewYear(v => v + 1) } else setViewMonth(m => m + 1) }

  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate()
  const firstDayOfWeek = new Date(viewYear, viewMonth, 1).getDay()

  const calendarDays = useMemo(() => {
    const days = []
    for (let i = 0; i < firstDayOfWeek; i++) days.push(null)
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(viewYear, viewMonth, d)
      const dateStr = fmtDate(viewYear, viewMonth, d)
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
      const fullyPast = allowPastDates ? date >= today : date < today
      days.push({ day: d, dateStr, fullyPast })
    }
    return days
  }, [viewYear, viewMonth, daysInMonth, firstDayOfWeek, allowPastDates])

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-ocean-600" />
      </div>
    )
  }

  if (isOvernight) {
    const is24hr = bookingMode === '24hr'
    return (
      <div className="space-y-3">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Select Dates</label>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          {!overnightCheckIn
            ? 'Click a date to set check-in'
            : !overnightCheckOut
              ? 'Click a later date to set check-out'
              : 'Click any date to start a new selection'}
        </p>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-ocean-500 inline-block" /> Check-in
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-emerald-500 inline-block" /> Check-out
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-ocean-100 border border-ocean-300 inline-block" /> {is24hr ? 'Days (24hr)' : 'Nights'}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-3 h-3 rounded bg-red-400 inline-block" /> Booked
          </span>
        </div>

        <div className="flex items-center justify-between">
          <button type="button" onClick={prevMonth} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
            <ChevronLeft size={18} />
          </button>
          <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">
            {MONTHS[viewMonth]} {viewYear}
          </span>
          <button type="button" onClick={nextMonth} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
            <ChevronRight size={18} />
          </button>
        </div>

        <div className="border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden">
          <div className="grid grid-cols-7 bg-gray-50 dark:bg-gray-900 border-b dark:border-gray-700">
            {DAY_ABBR.map(d => (
              <div key={d} className="text-center text-[10px] font-semibold text-gray-500 dark:text-gray-400 py-1.5">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7">
            {calendarDays.map((cell, idx) => {
              if (!cell) return <div key={`e-${idx}`} className="border-b border-r border-gray-100 dark:border-gray-700 h-12" />

              const { day, dateStr, fullyPast } = cell
              const isPast = fullyPast || isSlotPast(dateStr, overnightSlotType)
              const isBk = isBooked(dateStr, overnightSlotType)
              const disabled = isPast || isBk

              const isCI = dateStr === overnightCheckIn
              const isCO = dateStr === overnightCheckOut
              const inRange = overnightSelectedDates.has(dateStr)
              const isCheckOutDay = overnightCheckOut && dateStr === overnightCheckOut

              let cellBg = ''
              let textClass = 'text-gray-700 dark:text-gray-300 hover:bg-ocean-50 dark:hover:bg-gray-700 cursor-pointer'

              if (isPast) {
                cellBg = 'bg-gray-50 dark:bg-gray-900'
                textClass = 'text-gray-300 dark:text-gray-600 cursor-not-allowed'
              } else if (isBk) {
                cellBg = 'bg-red-50 dark:bg-red-900/20'
                textClass = 'text-red-400 cursor-not-allowed'
              } else if (isCI) {
                cellBg = 'bg-ocean-500'
                textClass = 'text-white font-bold'
              } else if (isCheckOutDay) {
                cellBg = 'bg-emerald-500'
                textClass = 'text-white font-bold'
              } else if (inRange) {
                cellBg = overnightHasOverlap ? 'bg-red-100 dark:bg-red-900/30' : 'bg-ocean-100 dark:bg-ocean-900/30'
                textClass = overnightHasOverlap ? 'text-red-700 dark:text-red-300 font-semibold' : 'text-ocean-700 dark:text-ocean-300 font-semibold'
              }

              return (
                <button
                  key={dateStr}
                  type="button"
                  onClick={() => !disabled && handleOvernightDateClick(dateStr)}
                  disabled={disabled}
                  className={`border-b border-r border-gray-100 dark:border-gray-700 h-12 flex items-center justify-center text-sm transition-all ${cellBg} ${textClass}`}
                >
                  {day}
                </button>
              )
            })}
          </div>
        </div>

        {overnightHasOverlap && (
          <div className="flex items-start gap-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-300">
            <AlertTriangle size={16} className="mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold">This range overlaps with an existing booking.</p>
              <p className="text-xs mt-1">
                Conflicting: {overnightOverlaps.map(s => s.date).join(', ')}
              </p>
              <p className="text-xs mt-1">Please choose a different range.</p>
            </div>
          </div>
        )}

        {overnightCheckIn && !overnightHasOverlap && (
          <div className="text-xs text-gray-500 dark:text-gray-400 space-y-1">
            <div>
              <span className="font-medium text-gray-700 dark:text-gray-300">Check-in:</span>{' '}
              {labelSlot({ date: overnightCheckIn, slot: overnightSlotType })}{is24hr ? '' : ' at 2:00 PM'}
              {overnightCheckOut && (
                <>
                  {' '}<span className="font-medium text-gray-700 dark:text-gray-300">Check-out:</span>{' '}
                  {formatCheckOutDate(overnightCheckOut ? overnightSlots[overnightSlots.length - 1]?.date : overnightCheckIn)}{is24hr ? '' : ' at 12:00 NN'}
                </>
              )}
              {' '}— {overnightNights || 1} {is24hr ? (overnightNights || 1) !== 1 ? 'days' : 'day' : (overnightNights || 1) !== 1 ? 'nights' : 'night'}
            </div>
            <button
              type="button"
              onClick={() => { setOvernightCheckIn(null); setOvernightCheckOut(null) }}
              className="text-red-500 hover:text-red-700 underline"
            >
              Clear
            </button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Select Dates</label>

      <p className="text-xs text-gray-500 dark:text-gray-400">
        {!checkIn
          ? 'Click a date or a Day/Night slot to set check-in'
          : !checkOut
            ? 'Click a later date or slot to set check-out'
            : 'Click any date or slot to start a new selection'}
      </p>

      <div className="flex flex-wrap items-center gap-3 text-xs">
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-ocean-500 inline-block" /> Check-in
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-emerald-500 inline-block" /> Check-out
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-ocean-100 border border-ocean-300 inline-block" /> In range
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-red-400 inline-block" /> Booked
        </span>
      </div>

      <div className="flex items-center justify-between">
        <button type="button" onClick={prevMonth} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
          <ChevronLeft size={18} />
        </button>
        <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">
          {MONTHS[viewMonth]} {viewYear}
        </span>
        <button type="button" onClick={nextMonth} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
          <ChevronRight size={18} />
        </button>
      </div>

      <div className="border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden">
        <div className="grid grid-cols-7 bg-gray-50 dark:bg-gray-900 border-b dark:border-gray-700">
          {DAY_ABBR.map(d => (
            <div key={d} className="text-center text-[10px] font-semibold text-gray-500 dark:text-gray-400 py-1.5">{d}</div>
          ))}
        </div>

        <div className="grid grid-cols-7">
          {calendarDays.map((cell, idx) => {
            if (!cell) return <div key={`e-${idx}`} className="border-b border-r border-gray-100 dark:border-gray-700 h-16" />

            const { day, dateStr, fullyPast } = cell
            const dayPast   = fullyPast || isSlotPast(dateStr, 'day')
            const nightPast = fullyPast || isSlotPast(dateStr, 'night')
            const dayBk     = isBooked(dateStr, 'day')
            const nightBk   = isBooked(dateStr, 'night')
            const allDisabled = (dayPast || dayBk) && (nightPast || nightBk || isDayOnly)

            const isCheckInDate  = checkIn?.date === dateStr
            const isCheckOutDate = checkOut?.date === dateStr
            const inRange = rangeSet.has(slotKey(dateStr, 'day')) || rangeSet.has(slotKey(dateStr, 'night'))

            const dayIsCI  = checkIn?.date  === dateStr && checkIn?.slot  === 'day'
            const dayIsCO  = checkOut?.date === dateStr && checkOut?.slot === 'day'
            const nightIsCI  = checkIn?.date  === dateStr && checkIn?.slot  === 'night'
            const nightIsCO  = checkOut?.date === dateStr && checkOut?.slot === 'night'
            const daySel   = selectedSet.has(slotKey(dateStr, 'day'))
            const nightSel = selectedSet.has(slotKey(dateStr, 'night'))

            let cellBg = ''
            if (fullyPast) cellBg = 'bg-gray-50 dark:bg-gray-900 opacity-50'
            else if (isCheckInDate || isCheckOutDate) cellBg = 'bg-ocean-50 dark:bg-gray-900'
            else if (inRange) cellBg = 'bg-ocean-50/50 dark:bg-gray-900/50'

            function slotClass(slot, isBk, isPast, isSel, isCI, isCO) {
              if (isBk)   return 'bg-red-400 text-white cursor-not-allowed'
              if (isPast)  return 'bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed'
              if (isCI)   return 'bg-ocean-500 text-white shadow-sm ring-2 ring-ocean-600'
              if (isCO)   return 'bg-emerald-500 text-white shadow-sm ring-2 ring-emerald-600'
              if (isSel)  return slot === 'day'
                ? 'bg-ocean-400 text-white shadow-sm'
                : 'bg-slate-600 text-white shadow-sm'
              if (rangeSet.has(slotKey(dateStr, slot)) && hasOverlap)
                return 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 ring-1 ring-red-300 dark:ring-red-800'
              return slot === 'day'
                ? 'bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/50 cursor-pointer'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 cursor-pointer'
            }

            return (
              <div key={dateStr} className={`border-b border-r border-gray-100 dark:border-gray-700 p-0.5 ${cellBg}`}>
                <button
                  type="button"
                  onClick={() => !allDisabled && handleDateClick(dateStr)}
                  disabled={allDisabled}
                  className={`w-full text-center text-xs font-medium mb-0.5 rounded transition-colors ${
                    allDisabled
                      ? 'text-gray-400 dark:text-gray-600 cursor-not-allowed'
                      : isCheckInDate
                        ? 'text-ocean-700 font-bold'
                        : isCheckOutDate
                          ? 'text-emerald-700 font-bold'
                          : inRange
                            ? 'text-ocean-600 font-semibold'
                            : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer'
                  }`}
                >
                  {day}
                </button>

                <div className={`flex gap-0.5 ${isDayOnly ? 'justify-center' : ''}`}>
                  <button
                    type="button"
                    onClick={() => handleSlotClick(dateStr, 'day')}
                    disabled={dayPast || dayBk}
                    title={dayBk ? 'Booked' : dayPast ? 'Past' : dayIsCI ? 'Check-in (Day)' : dayIsCO ? 'Check-out (Day)' : 'Day (8AM–5PM)'}
                    className={`flex-1 h-7 rounded text-[9px] font-bold flex items-center justify-center transition-all ${
                      slotClass('day', dayBk, dayPast, daySel, dayIsCI, dayIsCO)
                    }`}
                  >
                    <Sun size={10} />
                  </button>

                  {!isDayOnly && (
                    <button
                      type="button"
                      onClick={() => handleSlotClick(dateStr, 'night')}
                      disabled={nightPast || nightBk}
                      title={nightBk ? 'Booked' : nightPast ? 'Past' : nightIsCI ? 'Check-in (Night)' : nightIsCO ? 'Check-out (Night)' : 'Night (5PM–8AM)'}
                      className={`flex-1 h-7 rounded text-[9px] font-bold flex items-center justify-center transition-all ${
                        slotClass('night', nightBk, nightPast, nightSel, nightIsCI, nightIsCO)
                      }`}
                    >
                      <Moon size={10} />
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {hasOverlap && (
        <div className="flex items-start gap-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 text-sm text-red-700 dark:text-red-300">
          <AlertTriangle size={16} className="mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-semibold">This range overlaps with an existing booking.</p>
            <p className="text-xs mt-1">
              Conflicting: {overlaps.map(s => `${s.slot === 'day' ? 'Day' : 'Night'} on ${s.date}`).join(', ')}
            </p>
            <p className="text-xs mt-1">Please choose a different range.</p>
          </div>
        </div>
      )}

      {checkIn && !hasOverlap && (
        <div className="text-xs text-gray-500 dark:text-gray-400">
          <span className="font-medium text-gray-700 dark:text-gray-300">Check-in:</span> {labelSlot(checkIn)}
          {checkOut && (
            <> {' '}<span className="font-medium text-gray-700 dark:text-gray-300">Check-out:</span> {labelSlot(checkOut)}</>
          )}
          {' '}— {selectedSlots.length} slot{selectedSlots.length !== 1 ? 's' : ''}
          <button
            type="button"
            onClick={() => { setCheckIn(null); setCheckOut(null) }}
            className="ml-2 text-red-500 hover:text-red-700 underline"
          >
            Clear
          </button>
        </div>
      )}
    </div>
  )
}