'use client'

import React, { useState, useEffect, useRef, useCallback, useMemo, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Eye, Users, UserCheck, DollarSign, ShoppingCart, Clock, CreditCard, MessageCircle, Send, CheckCircle, ChevronDown, ChevronRight, Activity, Shield, Fingerprint, ScrollText, Smartphone, Film, Settings, Star, ImageIcon, ClipboardList, Newspaper, Calendar, Percent, BedDouble, FileDown, Mail, CalendarCheck, Tag, Home, CalendarPlus, Plus, Briefcase, Banknote, FileText, Timer, Palmtree, BarChart3 } from 'lucide-react'
import toast from 'react-hot-toast'
import useAuthStore from '@/store/authStore'
import api from '@/lib/api'
import SlotPicker from '@/components/SlotPicker'
import RoomOccupancySection from '@/components/admin/RoomOccupancySection'
import UniqueVisitorsSection from '@/components/admin/UniqueVisitorsSection'

const statCards = [
  { key: 'total_page_views', label: 'Total Page Views', icon: Eye, color: 'text-blue-600', bg: 'bg-blue-50', superadminOnly: true },
  { key: 'unique_visitors', label: 'Unique Visitors', icon: Users, color: 'text-purple-600', bg: 'bg-purple-50', superadminOnly: true },
  { key: 'net_income', label: 'Net Income', icon: DollarSign, color: 'text-green-600', bg: 'bg-green-50', isCurrency: true },
  { key: 'total_sales', label: 'Total Sales', icon: ShoppingCart, color: 'text-ocean-600', bg: 'bg-ocean-50' },
  { key: 'pending_sales', label: 'Pending Sales', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
  { key: 'pending_payments', label: 'Pending Payments', icon: CreditCard, color: 'text-red-600', bg: 'bg-red-50' },
  { key: 'unique_guests_count', label: 'Unique Guests', icon: UserCheck, color: 'text-teal-600', bg: 'bg-teal-50', superadminOnly: true },
  { key: 'active_visitors_count', label: 'Active Visitors (90d)', icon: Activity, color: 'text-indigo-600', bg: 'bg-indigo-50', superadminOnly: true },
]

function AdminDashboardContent() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  // Use selectors so this component doesn't re-render on unrelated store updates
  // (InactivityGuard touches `lastActivity` on every mousemove/keydown/scroll/
  // touchstart, which would otherwise churn this page constantly).
  const user = useAuthStore((s) => s.user)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const isReady = useAuthStore((s) => s.isReady)
  const router = useRouter()
  const searchParams = useSearchParams()

  // Onsite booking state
  const [rooms, setRooms] = useState([])
  const [vouchers, setVouchers] = useState([])
  const [showOnsiteForm, setShowOnsiteForm] = useState(false)
  const [onsiteForm, setOnsiteForm] = useState({
    guest_name: '', guest_username: '', guest_phone: '',
    room: '', guests: 1, slots: [], special_requests: '', manual_discount: '', manual_discount_type: 'fixed',
  })
  const [creatingOnsite, setCreatingOnsite] = useState(false)
  const [isBackdateMode, setIsBackdateMode] = useState(false)
  const [excludeFromSales, setExcludeFromSales] = useState(false)
  const [onsiteVoucherCode, setOnsiteVoucherCode] = useState('')
  const [bookingRefreshKey, setBookingRefreshKey] = useState(0)
  const [defaultCheckIn, setDefaultCheckIn] = useState(null)
  const [defaultCheckOut, setDefaultCheckOut] = useState(null)
  const onsiteSectionRef = useRef(null)
  const guestNameRef = useRef(null)

  const selectedRoom = useMemo(() => {
    if (!onsiteForm.room) return null
    return rooms.find(r => r.id == onsiteForm.room) || null
  }, [onsiteForm.room, rooms])

  const onsiteVoucherPreview = useMemo(() => {
    if (!onsiteVoucherCode.trim() || vouchers.length === 0) return null
    const v = vouchers.find(v => v.code.toLowerCase() === onsiteVoucherCode.trim().toLowerCase())
    if (!v) return { error: 'Voucher not found' }
    if (!v.is_active) return { error: 'Voucher is inactive' }
    if (v.max_uses && v.times_used >= v.max_uses) return { error: 'Voucher fully used' }

    // Validate against booking dates (same logic as backend) instead of current time
    const bookingDates = onsiteForm.slots.map(s => s.date).filter(Boolean)
    if (bookingDates.length > 0) {
      const vFrom = v.valid_from?.split('T')[0] || v.valid_from
      const vUntil = v.valid_until?.split('T')[0] || v.valid_until
      const earliest = bookingDates.sort()[0]
      const latest = bookingDates.sort()[bookingDates.length - 1]
      if (earliest < vFrom) return { error: 'Voucher not yet valid for selected dates' }
      if (latest > vUntil) return { error: 'Voucher expired for selected dates' }
    } else {
      // No slots selected yet — check against current date
      const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Manila' }))
      if (now < new Date(v.valid_from)) return { error: 'Voucher not yet valid' }
      if (now > new Date(v.valid_until)) return { error: 'Voucher expired' }
    }

    return {
      valid: true,
      label: v.discount_type === 'percentage' ? `${v.discount_value}% off` : `₱${v.discount_value} off`,
    }
  }, [onsiteVoucherCode, vouchers, onsiteForm.slots])

  // Page views collapse state
  const [pageViewsOpen, setPageViewsOpen] = useState(false)
  const [expandedPaths, setExpandedPaths] = useState({})

  // Unique guests collapse state
  const [guestsOpen, setGuestsOpen] = useState(false)
  const [expandedGuests, setExpandedGuests] = useState({})

  // Chat state
  const [conversations, setConversations] = useState([])
  const [activeConvo, setActiveConvo] = useState(null)
  const [convoMessages, setConvoMessages] = useState([])
  const [replyText, setReplyText] = useState('')
  const [sendingReply, setSendingReply] = useState(false)
  const chatEndRef = useRef(null)
  const pollRef = useRef(null)
  useEffect(() => {
    // Wait for AuthValidator to finish bootstrapping before making any
    // navigation decisions. Acting on partial auth state is what caused the
    // original /admin-dashboard ↔ /dashboard redirect loop.
    if (!isReady) return

    if (!isAuthenticated) {
      router.replace('/auth/login?redirect=/admin-dashboard')
      return
    }

    if (!user?.is_staff) {
      router.replace('/dashboard')
      return
    }

    // All staff can now fetch analytics (backend filters superadmin-only data).
    // Crucially: we NEVER redirect on analytics failure — doing so
    // previously caused an infinite loop with /dashboard.
    api.get('/analytics/dashboard/')
      .then((res) => {
        const d = res.data
        d.active_visitors_count = (d.unique_visitors_list || []).length
        setData(d)
        setLoading(false)
      })
      .catch(() => {
        setData({})
        setLoading(false)
      })

    fetchConversations()
    fetchRooms()
    fetchVouchers()
  }, [isReady, isAuthenticated, user, router])

  // Pre-fill room from URL query param (staff redirect from Rooms page)
  useEffect(() => {
    const roomParam = searchParams.get('room')
    const slotsParam = searchParams.get('slots')
    const guestsParam = searchParams.get('guests')
    const specialRequestsParam = searchParams.get('special_requests')
    const checkInParam = searchParams.get('checkIn')
    const checkOutParam = searchParams.get('checkOut')
    if (roomParam && rooms.length > 0) {
      const roomExists = rooms.find(r => r.id == roomParam)
      if (roomExists) {
        let parsedSlots = []
        if (slotsParam) {
          try { parsedSlots = JSON.parse(slotsParam) } catch {}
        }
        let parsedCheckIn = null
        let parsedCheckOut = null
        if (checkInParam) { try { parsedCheckIn = JSON.parse(checkInParam) } catch {} }
        if (checkOutParam) { try { parsedCheckOut = JSON.parse(checkOutParam) } catch {} }
        setOnsiteForm(f => ({
          ...f,
          room: roomParam,
          slots: parsedSlots,
          guests: guestsParam ? parseInt(guestsParam) : f.guests,
          special_requests: specialRequestsParam || f.special_requests,
        }))
        if (parsedCheckIn) setDefaultCheckIn(parsedCheckIn)
        if (parsedCheckOut) setDefaultCheckOut(parsedCheckOut)
        setShowOnsiteForm(true)
        setTimeout(() => {
          onsiteSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
          setTimeout(() => guestNameRef.current?.focus(), 500)
        }, 100)
      }
    }
  }, [searchParams, rooms])

  // Poll for new messages in active conversation
  useEffect(() => {
    if (!activeConvo) return
    const poll = () => {
      const lastMsg = convoMessages[convoMessages.length - 1]
      const since = lastMsg ? lastMsg.created_at : ''
      api.get(`/chat/conversations/${activeConvo.id}/poll/?since=${encodeURIComponent(since)}`)
        .then(({ data }) => {
          if (data.length > 0) {
            setConvoMessages(prev => {
              const existingIds = new Set(prev.map(m => m.id))
              const newMsgs = data.filter(m => !existingIds.has(m.id))
              return newMsgs.length > 0 ? [...prev, ...newMsgs] : prev
            })
          }
        })
        .catch(() => {})
    }
    pollRef.current = setInterval(poll, 5000)
    return () => clearInterval(pollRef.current)
  }, [activeConvo, convoMessages])

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [convoMessages])

  const fetchConversations = async () => {
    try {
      const { data } = await api.get('/chat/admin/conversations/')
      setConversations(data)
    } catch {}
  }

  const fetchRooms = async () => {
    try {
      const { data } = await api.get('/rooms/')
      setRooms(data.results || data)
    } catch {}
  }

  const fetchVouchers = async () => {
    try {
      const { data } = await api.get('/vouchers/')
      setVouchers(data)
    } catch {}
  }

  const handleCreateOnsiteBooking = async (e) => {
    e.preventDefault()
    if (onsiteForm.slots.length === 0) { toast.error('Add at least one slot.'); return }
    setCreatingOnsite(true)
    try {
      const payload = {
        guest_name: onsiteForm.guest_name,
        guest_username: onsiteForm.guest_username || undefined,
        guest_phone: onsiteForm.guest_phone || undefined,
        room: parseInt(onsiteForm.room),
        guests: parseInt(onsiteForm.guests),
        slots: onsiteForm.slots,
        special_requests: onsiteForm.special_requests,
      }
      if (isBackdateMode) payload.backdate = true
      if (excludeFromSales) payload.excluded_from_sales = true
      if (onsiteVoucherCode.trim()) payload.voucher_code = onsiteVoucherCode.trim()
      if (onsiteForm.manual_discount) {
        payload.manual_discount = parseFloat(onsiteForm.manual_discount)
        payload.manual_discount_type = onsiteForm.manual_discount_type || 'fixed'
      }
      const { data } = await api.post('/bookings/onsite/', payload)
      let msg = isBackdateMode
        ? `Backdated booking recorded! #${data.id} - ${data.room} - ₱${data.total_price} (COMPLETED)`
        : `Onsite booking created! #${data.id} - ${data.room} - ₱${data.total_price}`
      if (data.manual_discount) {
        const discountLabel = data.manual_discount_type === 'percentage' ? `${onsiteForm.manual_discount}% (₱${data.manual_discount})` : `₱${data.manual_discount}`
        msg += ` (${discountLabel} discount)`
      }
      if (data.discount) msg += ` (₱${data.discount} voucher discount with ${data.voucher_code})`
      toast.success(msg)
      setOnsiteForm({ guest_name: '', guest_username: '', guest_phone: '', room: '', guests: 1, slots: [], special_requests: '', manual_discount: '', manual_discount_type: 'fixed' })
      setOnsiteVoucherCode('')
      setIsBackdateMode(false)
      setExcludeFromSales(false)
      setShowOnsiteForm(false)
      setBookingRefreshKey(k => k + 1)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to create booking.')
    } finally {
      setCreatingOnsite(false)
    }
  }

  const openConversation = async (convo) => {
    setActiveConvo(convo)
    try {
      const { data } = await api.get(`/chat/conversations/${convo.id}/`)
      setConvoMessages(data.messages)
    } catch { toast.error('Failed to load conversation.') }
  }

  const handleSendReply = async () => {
    if (!replyText.trim() || !activeConvo) return
    setSendingReply(true)
    try {
      const { data } = await api.post(`/chat/conversations/${activeConvo.id}/send/`, { content: replyText.trim() })
      setConvoMessages(prev => [...prev, data])
      setReplyText('')
      fetchConversations()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to send message.')
    } finally {
      setSendingReply(false)
    }
  }

  const handleResolve = async () => {
    if (!activeConvo) return
    try {
      await api.patch(`/chat/admin/conversations/${activeConvo.id}/resolve/`)
      setActiveConvo(prev => ({ ...prev, status: 'resolved' }))
      fetchConversations()
      toast.success('Conversation resolved.')
    } catch { toast.error('Failed to resolve.') }
  }

  const togglePathExpand = (path) => {
    setExpandedPaths(prev => ({ ...prev, [path]: !prev[path] }))
  }

  const toggleGuestExpand = (userId) => {
    setExpandedGuests(prev => ({ ...prev, [userId]: !prev[userId] }))
  }

  if (loading || !data) {
    return (
      <div className="min-h-screen pt-24 pb-12 px-4 max-w-7xl mx-auto">
        <h1 className="text-3xl font-serif font-bold text-ocean-800 dark:text-ocean-200 mb-8">Admin Dashboard</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-3" />
              <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3" />
            </div>
          ))}
        </div>
        <div className="card p-6 animate-pulse">
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4" />
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 max-w-7xl mx-auto">
      <h1 className="text-3xl font-serif font-bold text-ocean-800 dark:text-ocean-200 mb-8">Admin Dashboard</h1>

      {/* Management Section */}
      <div className="mb-8">
        <h3 className="text-sm font-semibold text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Management</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
          <Link href="/admin-dashboard/analytics" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-ocean-200 bg-ocean-50/40 hover:bg-ocean-50 hover:border-ocean-400 transition-all text-center group">
            <BarChart3 size={20} className="text-ocean-600 group-hover:text-ocean-700" />
            <span className="text-sm font-medium text-ocean-700 group-hover:text-ocean-800 dark:text-ocean-200">Analytics</span>
          </Link>
          <Link href="/admin-dashboard/bookings" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <CalendarCheck size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Bookings</span>
          </Link>
          <Link href="/admin-dashboard/payments" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <CreditCard size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Payments</span>
          </Link>
          <Link href="/admin-dashboard/vouchers" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Tag size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Vouchers</span>
          </Link>
          <Link href="/admin-dashboard/occupancy" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Home size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Room Overview</span>
          </Link>
          <Link href="/admin-dashboard/reviews" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Star size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Reviews</span>
          </Link>
          {user?.is_superadmin && (
            <>
              <Link href="/admin-dashboard/users" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Shield size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Users</span>
              </Link>
              <Link href="/admin-dashboard/login-activity" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <ScrollText size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Login Activity</span>
              </Link>
              <Link href="/admin-dashboard/devices" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Fingerprint size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Devices</span>
              </Link>
              <Link href="/admin-dashboard/gcash" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Smartphone size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">GCash Settings</span>
              </Link>
              <Link href="/admin-dashboard/settings" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Settings size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Site Settings</span>
              </Link>
              <Link href="/admin-dashboard/manage-rooms" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <BedDouble size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Manage Rooms</span>
              </Link>
              <Link href="/admin-dashboard/pricing" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <DollarSign size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Pricing</span>
              </Link>
              <Link href="/admin-dashboard/activity-log" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <ClipboardList size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Activity Log</span>
              </Link>
            </>
          )}
          {(user?.is_admin || user?.is_superadmin) && (
            <>
              <Link href="/admin-dashboard/employees" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Briefcase size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Employees</span>
              </Link>
              <Link href="/admin-dashboard/payroll" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <DollarSign size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Payroll</span>
              </Link>
              <Link href="/admin-dashboard/payslips" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <FileText size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Payslips</span>
              </Link>
              <Link href="/admin-dashboard/loans" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Banknote size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Loans</span>
              </Link>
              <Link href="/admin-dashboard/pay-rates" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Percent size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Pay Rates</span>
              </Link>
              <Link href="/admin-dashboard/holidays" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Calendar size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Holidays</span>
              </Link>
              <Link href="/admin-dashboard/shifts" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Clock size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Shifts</span>
              </Link>
              <Link href="/admin-dashboard/attendance" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Timer size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Attendance</span>
              </Link>
              <Link href="/admin-dashboard/leave" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
                <Palmtree size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Leave</span>
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Content Section */}
      <div className="mb-8">
        <h3 className="text-sm font-semibold text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Content</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
          <Link href="/admin-dashboard/hero" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Film size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Homepage Intro</span>
          </Link>
          <Link href="/admin-dashboard/rooms" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <ImageIcon size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Room Photos</span>
          </Link>
          <Link href="/admin-dashboard/news" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Newspaper size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">News</span>
          </Link>
          <Link href="/admin-dashboard/events" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Calendar size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Events</span>
          </Link>
          <Link href="/admin-dashboard/promotions" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Percent size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Promotions</span>
          </Link>
          <Link href="/admin-dashboard/subscribers" className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group">
            <Mail size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Subscribers</span>
          </Link>
        </div>
      </div>

      {/* Exports Section */}
      <div className="mb-8">
        <h3 className="text-sm font-semibold text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-3">Exports</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
          <button
            onClick={async () => {
              try {
                const res = await api.get('/analytics/export/bookings/', { responseType: 'blob' })
                const url = URL.createObjectURL(res.data)
                const a = document.createElement('a'); a.href = url; a.download = 'bookings-export.csv'; a.click()
                URL.revokeObjectURL(url)
              } catch { toast.error('Export failed') }
            }}
            className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group"
          >
            <FileDown size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Export Bookings</span>
          </button>
          <button
            onClick={async () => {
              try {
                const res = await api.get('/analytics/export/revenue/', { responseType: 'blob' })
                const url = URL.createObjectURL(res.data)
                const a = document.createElement('a'); a.href = url; a.download = 'revenue-export.csv'; a.click()
                URL.revokeObjectURL(url)
              } catch { toast.error('Export failed') }
            }}
            className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group"
          >
            <FileDown size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Export Revenue</span>
          </button>
          <button
            onClick={async () => {
              try {
                const res = await api.get('/analytics/export/breakdowns/', { responseType: 'blob' })
                const url = URL.createObjectURL(res.data)
                const a = document.createElement('a'); a.href = url; a.download = 'revenue-breakdowns.csv'; a.click()
                URL.revokeObjectURL(url)
              } catch { toast.error('Export failed') }
            }}
            className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group"
          >
            <FileDown size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Export Breakdowns</span>
          </button>
          <button
            onClick={async () => {
              try {
                const res = await api.get('/analytics/export/vouchers/', { responseType: 'blob' })
                const url = URL.createObjectURL(res.data)
                const a = document.createElement('a'); a.href = url; a.download = 'voucher-roi.csv'; a.click()
                URL.revokeObjectURL(url)
              } catch { toast.error('Export failed') }
            }}
            className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group"
          >
            <FileDown size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Export Vouchers</span>
          </button>
          <button
            onClick={async () => {
              try {
                const res = await api.get('/analytics/export/cancellations/', { responseType: 'blob' })
                const url = URL.createObjectURL(res.data)
                const a = document.createElement('a'); a.href = url; a.download = 'cancellations.csv'; a.click()
                URL.revokeObjectURL(url)
              } catch { toast.error('Export failed') }
            }}
            className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group"
          >
            <FileDown size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Export Cancellations</span>
          </button>
          {user?.is_superadmin && (
            <button
              onClick={async () => {
                try {
                  const res = await api.get('/analytics/export/top-guests/', { responseType: 'blob' })
                  const url = URL.createObjectURL(res.data)
                  const a = document.createElement('a'); a.href = url; a.download = 'top-guests.csv'; a.click()
                  URL.revokeObjectURL(url)
                } catch { toast.error('Export failed') }
              }}
              className="flex flex-col items-center justify-center gap-1.5 p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:bg-ocean-50 hover:border-ocean-300 transition-all text-center group"
            >
              <FileDown size={20} className="text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 group-hover:text-ocean-600" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 group-hover:text-ocean-700">Export Top Guests</span>
            </button>
          )}
        </div>
      </div>

      {/* Stat Cards — visible to all staff, superadmin-only cards filtered */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {statCards.filter(c => !c.superadminOnly || user?.is_superadmin).map(({ key, label, icon: Icon, color, bg, isCurrency }) => (
            <div key={key} className="card p-6 flex items-center gap-4">
              <div className={`${bg} p-3 rounded-xl`}>
                <Icon className={`${color} w-6 h-6`} />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">{label}</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {isCurrency
                    ? `₱${Number(data[key] || 0).toLocaleString('en-PH', { minimumFractionDigits: 2 })}`
                    : Number(data[key] || 0).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
      </div>

      {/* Onsite Booking */}
      <div ref={onsiteSectionRef} className="card overflow-hidden mb-10">
        <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-ocean-800 dark:text-ocean-200 flex items-center gap-2">
            <CalendarPlus size={20} /> Onsite Booking
          </h2>
          <button
            onClick={() => setShowOnsiteForm(!showOnsiteForm)}
            className="btn-primary text-sm px-3 py-1.5 flex items-center gap-1"
          >
            <Plus size={14} /> Walk-in Booking
          </button>
        </div>

        {showOnsiteForm && (
          <form onSubmit={handleCreateOnsiteBooking} className="p-6 bg-gray-50 dark:bg-gray-900">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Guest Name *</label>
                <input ref={guestNameRef} type="text" required value={onsiteForm.guest_name}
                  onChange={e => setOnsiteForm(f => ({ ...f, guest_name: e.target.value }))}
                  className="input-field" placeholder="e.g. Juan Dela Cruz" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Username (optional)</label>
                <input type="text" value={onsiteForm.guest_username}
                  onChange={e => setOnsiteForm(f => ({ ...f, guest_username: e.target.value }))}
                  className="input-field" placeholder="guest username" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Phone (optional)</label>
                <input type="text" value={onsiteForm.guest_phone}
                  onChange={e => setOnsiteForm(f => ({ ...f, guest_phone: e.target.value }))}
                  className="input-field" placeholder="09XX XXX XXXX" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Room *</label>
                <select required value={onsiteForm.room}
                  onChange={e => setOnsiteForm(f => ({ ...f, room: e.target.value, slots: [] }))}
                  className="input-field">
                  <option value="">Select a room</option>
                  {rooms.map(r => (
                    <option key={r.id} value={r.id}>{r.name} (max {r.capacity} pax)</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Guests</label>
                <input type="number" min="1" required value={onsiteForm.guests}
                  onChange={e => setOnsiteForm(f => ({ ...f, guests: e.target.value }))}
                  className="input-field" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Special Requests</label>
                <input type="text" value={onsiteForm.special_requests}
                  onChange={e => setOnsiteForm(f => ({ ...f, special_requests: e.target.value }))}
                  className="input-field" placeholder="Optional notes" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Voucher Code (optional)</label>
                <input type="text" value={onsiteVoucherCode}
                  onChange={e => setOnsiteVoucherCode(e.target.value)}
                  className="input-field" placeholder="e.g. SUMMER20" />
                {onsiteVoucherPreview && (
                  <p className={`text-xs mt-1 ${onsiteVoucherPreview.valid ? 'text-green-600' : 'text-red-500'}`}>
                    {onsiteVoucherPreview.valid ? onsiteVoucherPreview.label : onsiteVoucherPreview.error}
                  </p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Discount (optional)</label>
                <div className="flex gap-0">
                  <input type="number" min="0" step={onsiteForm.manual_discount_type === 'percentage' ? '1' : '0.01'}
                    value={onsiteForm.manual_discount}
                    onChange={e => setOnsiteForm(f => ({ ...f, manual_discount: e.target.value }))}
                    className="input-field w-1/2 rounded-r-none border-r-0" placeholder="0" />
                  <select value={onsiteForm.manual_discount_type} onChange={e => setOnsiteForm(f => ({ ...f, manual_discount_type: e.target.value }))}
                    className="input-field w-1/2 rounded-l-none border-l-0">
                    <option value="fixed">₱ Fixed</option>
                    <option value="percentage">% Percent</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isBackdateMode}
                  onChange={e => {
                    setIsBackdateMode(e.target.checked)
                    setOnsiteForm(f => ({ ...f, slots: [] }))
                  }}
                  className="rounded border-gray-300 dark:border-gray-600 text-amber-600 focus:ring-amber-500"
                />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Backdate Booking</span>
              </label>
              {isBackdateMode && (
                <span className="text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                  Recording a past stay — will be saved as COMPLETED
                </span>
              )}
              <label className="flex items-center gap-2 cursor-pointer ml-4">
                <input
                  type="checkbox"
                  checked={excludeFromSales}
                  onChange={e => setExcludeFromSales(e.target.checked)}
                  className="rounded border-gray-300 dark:border-gray-600 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Exclude from Sales / Net Income</span>
              </label>
              {excludeFromSales && (
                <span className="text-xs text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                  Will not count toward sales or revenue
                </span>
              )}
            </div>

            {selectedRoom && (
              <div className="mt-4">
                <SlotPicker
                  key={`${selectedRoom.id}-${defaultCheckIn ? 'init' : 'empty'}-${isBackdateMode ? 'bd' : 'normal'}`}
                  roomId={selectedRoom.id}
                  isDayOnly={selectedRoom.is_day_only}
                  bookingMode={selectedRoom.booking_mode}
                  onSlotsChange={(slots) => setOnsiteForm(f => ({ ...f, slots }))}
                  defaultCheckIn={defaultCheckIn}
                  defaultCheckOut={defaultCheckOut}
                  allowPastDates={isBackdateMode}
                />
              </div>
            )}

            {!selectedRoom && (
              <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg text-sm text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-center">
                Select a room to see the availability calendar
              </div>
            )}

            <div className="mt-4 flex gap-2">
              <button type="submit" disabled={creatingOnsite} className="btn-primary text-sm px-4 py-2 disabled:opacity-50">
                {creatingOnsite ? 'Creating...' : isBackdateMode ? 'Record Past Booking' : 'Create Booking'}
              </button>
              <button type="button" onClick={() => setShowOnsiteForm(false)} className="btn-outline text-sm px-4 py-2">Cancel</button>
            </div>
          </form>
        )}
      </div>

      {/* Chat Conversations */}
      <div className="card overflow-hidden mb-10">
        <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-ocean-800 dark:text-ocean-200 flex items-center gap-2">
            <MessageCircle size={20} /> Chat Conversations
          </h2>
        </div>
        <div className="flex" style={{ minHeight: '400px' }}>
          {/* Conversation List */}
          <div className="w-1/3 border-r border-gray-100 dark:border-gray-700 overflow-y-auto" style={{ maxHeight: '500px' }}>
            {conversations.length === 0 && (
              <p className="p-6 text-center text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-sm">No conversations yet</p>
            )}
            {conversations.map(c => (
              <button
                key={c.id}
                onClick={() => openConversation(c)}
                className={`w-full text-left px-4 py-3 border-b border-gray-50 dark:border-gray-700 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors ${activeConvo?.id === c.id ? 'bg-ocean-50' : ''}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-gray-800 dark:text-gray-200 truncate">{c.customer_name}</span>
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${c.status === 'open' ? 'bg-green-100 text-green-700' : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500'}`}>
                    {c.status}
                  </span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 truncate">{c.subject}</p>
                {c.last_message && (
                  <p className="text-xs text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 truncate mt-0.5">{c.last_message.content}</p>
                )}
                {c.unread_count > 0 && (
                  <span className="inline-block mt-1 bg-ocean-600 text-white text-xs rounded-full px-2 py-0.5">
                    {c.unread_count} new
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Chat Thread */}
          <div className="flex-1 flex flex-col">
            {!activeConvo ? (
              <div className="flex-1 flex items-center justify-center text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-sm">
                Select a conversation to view messages
              </div>
            ) : (
              <>
                <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between bg-gray-50 dark:bg-gray-900">
                  <div>
                    <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">{activeConvo.customer_name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">{activeConvo.subject}</p>
                  </div>
                  {activeConvo.status === 'open' && (
                    <button onClick={handleResolve} className="text-xs bg-green-100 text-green-700 hover:bg-green-200 px-3 py-1.5 rounded-lg flex items-center gap-1">
                      <CheckCircle size={12} /> Resolve
                    </button>
                  )}
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ maxHeight: '350px' }}>
                  {convoMessages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.is_staff_reply ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] rounded-xl px-3 py-2 ${msg.is_staff_reply ? 'bg-ocean-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200'}`}>
                        <p className="text-sm">{msg.content}</p>
                        <p className={`text-xs mt-1 ${msg.is_staff_reply ? 'text-ocean-200' : 'text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500'}`}>
                          {msg.sender_name} · {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
                {activeConvo.status === 'open' && (
                  <div className="p-3 border-t border-gray-100 dark:border-gray-700 flex gap-2">
                    <input
                      type="text"
                      value={replyText}
                      onChange={e => setReplyText(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSendReply()}
                      placeholder="Type a reply..."
                      className="flex-1 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-ocean-500 focus:border-transparent"
                    />
                    <button onClick={handleSendReply} disabled={sendingReply || !replyText.trim()}
                      className="btn-primary px-3 py-2 disabled:opacity-50">
                      <Send size={16} />
                    </button>
                  </div>
                )}
                {activeConvo.status === 'resolved' && (
                  <div className="p-3 border-t border-gray-100 dark:border-gray-700 text-center text-sm text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">
                    This conversation has been resolved
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Unique Guests — superadmin only */}
      {user?.is_superadmin && <div className="card overflow-hidden mb-10">
        <button
          onClick={() => setGuestsOpen(!guestsOpen)}
          className="w-full px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors"
        >
          <h2 className="text-lg font-semibold text-ocean-800 dark:text-ocean-200 flex items-center gap-2">
            <UserCheck size={20} /> Unique Guests
          </h2>
          {guestsOpen ? <ChevronDown size={20} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500" /> : <ChevronRight size={20} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500" />}
        </button>
        {guestsOpen && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-900">
                <tr>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Guest</th>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Contact</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Bookings</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Total Spent</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Last Booking</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {(data.unique_guests || []).map((guest) => {
                  const userId = guest.user__id
                  const isExpanded = expandedGuests[userId]
                  const bookings = isExpanded
                    ? (data.guest_bookings || []).filter(b => b.user__id === userId)
                    : []
                  return (
                    <React.Fragment key={userId}>
                      <tr
                        className="hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors cursor-pointer"
                        onClick={() => toggleGuestExpand(userId)}
                      >
                        <td className="px-6 py-3 text-sm text-gray-700 dark:text-gray-300 flex items-center gap-2">
                          {isExpanded
                            ? <ChevronDown size={14} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 flex-shrink-0" />
                            : <ChevronRight size={14} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 flex-shrink-0" />}
                          <span className="font-medium">{guest.guest_name?.trim() || 'Unknown'}</span>
                        </td>
                        <td className="px-6 py-3 text-sm text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">
                          <div>{guest.username && !guest.username.startsWith('walkin-') ? guest.username : '\u2014'}</div>
                          {guest.phone && <div className="text-xs text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">{guest.phone}</div>}
                        </td>
                        <td className="px-6 py-3 text-sm text-gray-900 dark:text-gray-100 font-semibold text-right">{guest.total_bookings}</td>
                        <td className="px-6 py-3 text-sm text-gray-900 dark:text-gray-100 font-semibold text-right">
                          ₱{Number(guest.total_spent).toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="px-6 py-3 text-sm text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right">
                          {guest.last_booking ? new Date(guest.last_booking).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '\u2014'}
                        </td>
                      </tr>
                      {isExpanded && bookings.map((b) => (
                        <tr key={b.id} className="bg-gray-50 dark:bg-gray-900/60">
                          <td className="px-6 pl-14 py-2 text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">
                            #{b.id} — {b.room__name}
                          </td>
                          <td className="px-6 py-2 text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">
                            {b.check_in} to {b.check_out}
                          </td>
                          <td className="px-6 py-2 text-xs text-gray-600 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right">
                            <span className={`inline-block px-1.5 py-0.5 rounded-full text-[10px] font-medium ${b.status === 'confirmed' ? 'bg-green-100 text-green-700' : b.status === 'completed' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500'}`}>
                              {b.status}
                            </span>
                          </td>
                          <td className="px-6 py-2 text-xs text-gray-600 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right">
                            ₱{Number(b.total_price).toLocaleString('en-PH', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="px-6 py-2 text-xs text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right">
                            {new Date(b.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </td>
                        </tr>
                      ))}
                      {isExpanded && bookings.length === 0 && (
                        <tr className="bg-gray-50 dark:bg-gray-900/60">
                          <td colSpan={5} className="px-6 pl-14 py-2 text-xs text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">No booking details available</td>
                        </tr>
                      )}
                    </React.Fragment>
                  )
                })}
                {(data.unique_guests || []).length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">No guest bookings yet</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>}

      {/* Unique Visitors — superadmin only */}
      {user?.is_superadmin && <UniqueVisitorsSection data={data} />}

      {/* Page Views Table — superadmin only */}
      {user?.is_superadmin && <div className="card overflow-hidden">
        <button
          onClick={() => setPageViewsOpen(!pageViewsOpen)}
          className="w-full px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors"
        >
          <h2 className="text-lg font-semibold text-ocean-800 dark:text-ocean-200 flex items-center gap-2">
            <Eye size={20} /> Page Views by Path
          </h2>
          {pageViewsOpen ? <ChevronDown size={20} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500" /> : <ChevronRight size={20} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500" />}
        </button>
        {pageViewsOpen && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-900">
                <tr>
                  <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Page Path</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Views</th>
                  <th className="text-right px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 uppercase tracking-wider">Last Viewed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {data.page_views.map((row) => {
                  const isExpanded = expandedPaths[row.page_path]
                  const dailyRows = isExpanded
                    ? (data.daily_page_views || []).filter(d => d.page_path === row.page_path)
                    : []
                  return (
                    <React.Fragment key={row.page_path}>
                      <tr
                        className="hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors cursor-pointer"
                        onClick={() => togglePathExpand(row.page_path)}
                      >
                        <td className="px-6 py-3 text-sm text-gray-700 dark:text-gray-300 font-mono flex items-center gap-2">
                          {isExpanded
                            ? <ChevronDown size={14} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 flex-shrink-0" />
                            : <ChevronRight size={14} className="text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 flex-shrink-0" />}
                          {row.page_path}
                        </td>
                        <td className="px-6 py-3 text-sm text-gray-900 dark:text-gray-100 font-semibold text-right">{row.views.toLocaleString()}</td>
                        <td className="px-6 py-3 text-sm text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right whitespace-nowrap">
                          {row.last_viewed ? new Date(row.last_viewed).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '\u2014'}
                        </td>
                      </tr>
                      {isExpanded && (
                        <>
                          {(row.recent_accesses || []).length > 0 && (
                            <tr className="bg-gray-50 dark:bg-gray-900/40">
                              <td colSpan={3} className="px-6 pl-14 py-1 text-[10px] uppercase tracking-wider text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 font-semibold">
                                Recent accesses
                              </td>
                            </tr>
                          )}
                          {(row.recent_accesses || []).map((a, i) => (
                            <tr key={`${row.page_path}-acc-${i}`} className="bg-gray-50 dark:bg-gray-900/60">
                              <td className="px-6 pl-14 py-1.5 text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 font-mono">
                                {a.visitor_id ? `${a.visitor_id.slice(0, 8)}\u2026` : '\u2014'}
                              </td>
                              <td className="px-6 py-1.5"></td>
                              <td className="px-6 py-1.5 text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right whitespace-nowrap">
                                {new Date(a.timestamp).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </td>
                            </tr>
                          ))}
                          {dailyRows.length > 0 && (
                            <tr className="bg-gray-50 dark:bg-gray-900/40">
                              <td colSpan={3} className="px-6 pl-14 py-1 text-[10px] uppercase tracking-wider text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 font-semibold">
                                Daily totals
                              </td>
                            </tr>
                          )}
                          {dailyRows.map((d) => (
                            <tr key={`${row.page_path}-${d.view_date}`} className="bg-gray-50 dark:bg-gray-900/60">
                              <td className="px-6 pl-14 py-2 text-xs text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">
                                {new Date(d.view_date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                              </td>
                              <td className="px-6 py-2 text-xs text-gray-600 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500 text-right">{d.views.toLocaleString()}</td>
                              <td className="px-6 py-2"></td>
                            </tr>
                          ))}
                          {dailyRows.length === 0 && (row.recent_accesses || []).length === 0 && (
                            <tr className="bg-gray-50 dark:bg-gray-900/60">
                              <td colSpan={3} className="px-6 pl-14 py-2 text-xs text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">No data available</td>
                            </tr>
                          )}
                        </>
                      )}
                    </React.Fragment>
                  )
                })}
                {data.page_views.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-gray-400 dark:text-gray-500 dark:text-gray-400 dark:text-gray-500">No page views recorded yet</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>}
    </div>
  )
}

export default function AdminDashboard() {
  return (
    <Suspense fallback={
      <div className="min-h-screen pt-24 pb-12 px-4 max-w-7xl mx-auto">
        <h1 className="text-3xl font-serif font-bold text-ocean-800 dark:text-ocean-200 mb-8">Admin Dashboard</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="card p-6 animate-pulse">
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-3" />
              <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3" />
            </div>
          ))}
        </div>
      </div>
    }>
      <AdminDashboardContent />
    </Suspense>
  )
}
