'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Plus, Pencil, Trash2, ToggleLeft, ToggleRight, X, Send, ExternalLink } from 'lucide-react'
import { format, parseISO } from 'date-fns'
import toast from 'react-hot-toast'
import useAuthStore from '@/store/authStore'
import api from '@/lib/api'
import { cloudinaryUrl } from '@/lib/cloudinary'

export default function AdminEventsPage() {
  const { user } = useAuthStore()
  const router = useRouter()
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({ title: '', description: '', date: '', is_active: true })
  const [imageFile, setImageFile] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!user) return
    if (!user.is_staff) { router.push('/admin-dashboard'); return }
    fetchItems()
  }, [user])

  const fetchItems = async () => {
    try {
      const { data } = await api.get('/content/admin/events/')
      setItems(data)
    } catch { toast.error('Failed to load events') }
    finally { setLoading(false) }
  }

  const openCreate = () => {
    setEditing(null)
    setForm({ title: '', description: '', date: '', is_active: true })
    setImageFile(null)
    setShowForm(true)
  }

  const openEdit = (item) => {
    setEditing(item)
    setForm({ title: item.title, description: item.description, date: item.date, is_active: item.is_active })
    setImageFile(null)
    setShowForm(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    const fd = new FormData()
    fd.append('title', form.title)
    fd.append('description', form.description)
    fd.append('date', form.date)
    fd.append('is_active', form.is_active)
    if (imageFile) fd.append('image', imageFile)

    try {
      if (editing) {
        const { data } = await api.patch(`/content/admin/events/${editing.id}/`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
        setItems(prev => prev.map(i => i.id === editing.id ? data : i))
        toast.success('Event updated')
      } else {
        const { data } = await api.post('/content/admin/events/create/', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
        setItems(prev => [data, ...prev])
        toast.success('Event created')
      }
      setShowForm(false)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to save')
    } finally { setSubmitting(false) }
  }

  const handleDelete = async (id) => {
    if (!confirm('Delete this event?')) return
    try {
      await api.delete(`/content/admin/events/${id}/`)
      setItems(prev => prev.filter(i => i.id !== id))
      toast.success('Event deleted')
    } catch { toast.error('Failed to delete') }
  }

  const toggleActive = async (item) => {
    try {
      const { data } = await api.patch(`/content/admin/events/${item.id}/`, { is_active: !item.is_active })
      setItems(prev => prev.map(i => i.id === item.id ? data : i))
      toast.success(data.is_active ? 'Published' : 'Unpublished')
    } catch { toast.error('Failed to update') }
  }

  const handleBroadcast = async (item) => {
    const already = !!item.announcement_sent_at
    const msg = already
      ? `This event was already announced on ${format(parseISO(item.announcement_sent_at), 'MMM d, yyyy')}. Send again?`
      : `Send "${item.title}" to all newsletter subscribers and registered users?`
    if (!confirm(msg)) return
    try {
      const { data } = await api.post(`/content/admin/events/${item.id}/broadcast/`)
      toast.success(`Announcement sent to ${data.sent} recipient(s)`)
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, announcement_sent_at: data.announcement_sent_at } : i))
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Broadcast failed')
    }
  }

  if (loading) return <div className="min-h-screen pt-24 flex items-center justify-center"><div className="spinner" /></div>

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link href="/admin-dashboard" className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:text-gray-500 dark:hover:text-gray-300"><ArrowLeft size={20} /></Link>
            <h1 className="font-serif text-2xl font-bold text-gray-900 dark:text-gray-100">Manage Events</h1>
          </div>
          <button onClick={openCreate} className="btn-primary text-sm flex items-center gap-2"><Plus size={16} /> Add Event</button>
        </div>

        {showForm && (
          <div className="card p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg">{editing ? 'Edit Event' : 'Create Event'}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:text-gray-500 dark:hover:text-gray-300"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Title</label>
                <input type="text" className="input" required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
              </div>
              <div>
                <label className="label">Description</label>
                <textarea className="input min-h-[120px]" required value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="label">Event Date</label>
                  <input type="date" className="input" required value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Image</label>
                  <input type="file" accept="image/*" className="input" onChange={e => setImageFile(e.target.files[0])} />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="is_active" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} />
                <label htmlFor="is_active" className="text-sm text-gray-700 dark:text-gray-300">Active (visible to public)</label>
              </div>
              <button type="submit" disabled={submitting} className="btn-primary">
                {submitting ? 'Saving...' : editing ? 'Update' : 'Create'}
              </button>
            </form>
          </div>
        )}

        {items.length === 0 ? (
          <div className="card p-12 text-center text-gray-500 dark:text-gray-400 dark:text-gray-500">No events yet.</div>
        ) : (
          <div className="grid gap-4">
            {items.map(item => (
              <div key={item.id} className="card p-4 flex items-center gap-4">
                {item.image_url && (
                  <img src={cloudinaryUrl(item.image_url, { width: 100 })} alt={item.title} className="w-16 h-16 rounded-lg object-cover flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate">{item.title}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 dark:text-gray-500">{format(parseISO(item.date), 'MMM d, yyyy')}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-xs px-2 py-1 rounded-full ${item.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 dark:text-gray-500'}`}>
                    {item.is_active ? 'Active' : 'Inactive'}
                  </span>
                  {item.announcement_sent_at && (
                    <span className="text-[10px] text-gray-400 dark:text-gray-500">Sent {format(parseISO(item.announcement_sent_at), 'MMM d')}</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {item.is_active && (
                    <a
                      href={`/events/${item.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 text-gray-400 dark:text-gray-500 hover:text-ocean-600"
                      title="View on site"
                    >
                      <ExternalLink size={16} />
                    </a>
                  )}
                  <button
                    onClick={() => handleBroadcast(item)}
                    disabled={!item.is_active}
                    className="p-2 text-gray-400 dark:text-gray-500 hover:text-ocean-600 disabled:opacity-30 disabled:hover:text-gray-400 dark:text-gray-500"
                    title={item.is_active ? 'Send announcement to subscribers' : 'Activate to send'}
                  >
                    <Send size={16} />
                  </button>
                  <button onClick={() => toggleActive(item)} className="p-2 text-gray-400 dark:text-gray-500 hover:text-ocean-600" title={item.is_active ? 'Unpublish' : 'Publish'}>
                    {item.is_active ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                  </button>
                  <button onClick={() => openEdit(item)} className="p-2 text-gray-400 dark:text-gray-500 hover:text-ocean-600"><Pencil size={16} /></button>
                  <button onClick={() => handleDelete(item.id)} className="p-2 text-gray-400 dark:text-gray-500 hover:text-red-600"><Trash2 size={16} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
