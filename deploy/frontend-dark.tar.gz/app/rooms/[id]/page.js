export const dynamic = 'force-dynamic'

import { notFound } from 'next/navigation'
import { Users, Maximize, Check } from 'lucide-react'
import BookingForm from '@/components/BookingForm'
import RoomGallery from '@/components/RoomGallery'
import FavoriteButton from '@/components/FavoriteButton'
import { FadeInUp } from '@/components/motions'
import RoomReviews from '@/components/RoomReviews'
import api from '@/lib/api'

async function getRoom(id) {
  try {
    const { data } = await api.get(`/rooms/${id}/`)
    return data
  } catch {
    return null
  }
}

export async function generateMetadata({ params }) {
  const room = await getRoom(params.id)
  if (!room) return { title: 'Room not found' }
  return {
    title: room.name,
    description: room.description?.slice(0, 160),
    openGraph: {
      title: `${room.name} | Adel Beach Resort`,
      description: room.description?.slice(0, 160),
      images: room.primary_image ? [{ url: room.primary_image }] : [],
    },
    twitter: {
      card: 'summary_large_image',
      title: `${room.name} | Adel Beach Resort`,
      description: room.description?.slice(0, 160),
      images: room.primary_image ? [room.primary_image] : [],
    },
  }
}

const typeColors = {
  cottage: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
  dos_andanas: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
  lavender_house: 'bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/40 dark:text-fuchsia-300',
  ac_karaoke: 'bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300',
  kubo: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
  function_hall: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
  trapal_table: 'bg-lime-100 text-lime-700 dark:bg-lime-900/40 dark:text-lime-300',
}

export default async function RoomDetailPage({ params }) {
  const room = await getRoom(params.id)
  if (!room) notFound()

  return (
    <div className="min-h-screen pt-20 pb-16 dark:bg-gray-900">
      <div className="relative">
        <RoomGallery images={room.images || []} roomName={room.name} />
        <div className="absolute bottom-6 left-6 text-white z-20 pointer-events-none">
          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${typeColors[room.room_type] || 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'}`}>
            {room.room_type_display}
          </span>
          <h1 className="font-serif text-4xl font-bold mt-2">{room.name}</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-8">
            <FadeInUp>
              <div className="flex flex-wrap items-center gap-6 text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-2">
                  <Users className="text-ocean-500" size={20} />
                  <span>Up to <strong>{room.capacity}</strong> persons</span>
                </div>
                {room.size_sqm && (
                  <div className="flex items-center gap-2">
                    <Maximize className="text-ocean-500" size={20} />
                    <span><strong>{room.size_sqm}</strong> m²</span>
                  </div>
                )}
                <FavoriteButton roomId={room.id} />
              </div>
            </FadeInUp>

            <FadeInUp delay={0.1}>
              <h2 className="font-serif text-2xl font-bold text-gray-900 dark:text-gray-100 mb-3">About This Room</h2>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed text-lg">{room.description}</p>
            </FadeInUp>

            {room.amenities?.length > 0 && (
              <FadeInUp delay={0.2}>
                <h2 className="font-serif text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {room.amenities.map((amenity) => (
                    <div key={amenity} className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                      <div className="w-5 h-5 bg-ocean-100 dark:bg-ocean-900/30 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check size={12} className="text-ocean-600 dark:text-ocean-400" />
                      </div>
                      <span className="text-sm">{amenity}</span>
                    </div>
                  ))}
                </div>
              </FadeInUp>
            )}

            <FadeInUp delay={0.3}>
              <RoomReviews roomId={room.id} />
            </FadeInUp>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <BookingForm room={room} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}