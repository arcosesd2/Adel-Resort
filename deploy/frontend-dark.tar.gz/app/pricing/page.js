'use client'

import React, { useState, useEffect } from 'react'
import { DollarSign } from 'lucide-react'
import { FadeInUp } from '@/components/motions'
import api from '@/lib/api'

export default function PricingPage() {
  const [pricing, setPricing] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/content/pricing/')
      .then(({ data }) => setPricing(data.results || data))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  // Group pricing entries by room_type_display
  const grouped = pricing.reduce((acc, item) => {
    const key = item.room_type_display
    if (!acc[key]) acc[key] = []
    acc[key].push(item)
    return acc
  }, {})

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeInUp className="text-center mb-10">
          <p className="text-ocean-600 font-semibold tracking-widest text-sm uppercase mb-3">Our Rates</p>
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 dark:text-gray-100 mb-4">
            Pricing
          </h1>
          <p className="text-gray-500 dark:text-gray-400 text-lg max-w-2xl mx-auto">
            Transparent pricing for all our accommodations.
            <br />
            Day Tour: 8AM&ndash;5PM | Night Tour: 5PM&ndash;8AM
          </p>
        </FadeInUp>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="card animate-pulse p-6">
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4" />
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2" />
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
              </div>
            ))}
          </div>
        ) : pricing.length === 0 ? (
          <div className="text-center py-20">
            <DollarSign size={48} className="mx-auto text-gray-300 dark:text-gray-600 mb-4" />
            <h3 className="text-xl font-semibold text-gray-500 dark:text-gray-400 mb-2">Pricing coming soon</h3>
            <p className="text-gray-400 dark:text-gray-500">Please check back later for our rates.</p>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full table-fixed">
                  <colgroup>
                    <col className="w-[40%]" />
                    <col className="w-[18%]" />
                    <col className="w-[18%]" />
                    <col className="w-[24%]" />
                  </colgroup>
                  <thead>
                    <tr className="border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                      <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600 dark:text-gray-400">Accommodation</th>
                      <th className="text-right px-6 py-3 text-sm font-semibold text-gray-600 dark:text-gray-400">Day Rate</th>
                      <th className="text-right px-6 py-3 text-sm font-semibold text-gray-600 dark:text-gray-400">Night Rate</th>
                      <th className="text-left px-6 py-3 text-sm font-semibold text-gray-600 dark:text-gray-400">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(grouped).map(([roomType, items]) => (
                      <React.Fragment key={roomType}>
                        <tr>
                          <td colSpan={4} className="bg-ocean-600 px-6 py-3">
                            <h2 className="font-serif text-lg font-bold text-white">{roomType}</h2>
                          </td>
                        </tr>
                        {items.map((item) => (
                          <tr key={item.id} className="border-b last:border-0 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td className="px-6 py-4 text-gray-800 dark:text-gray-100 font-medium">{item.label}</td>
                            <td className="px-6 py-4 text-right text-gray-700 dark:text-gray-300">
                              ₱{Number(item.day_price).toLocaleString()}
                            </td>
                            <td className="px-6 py-4 text-right text-gray-700 dark:text-gray-300">
                              {item.night_price ? `₱${Number(item.night_price).toLocaleString()}` : '—'}
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{item.notes}</td>
                          </tr>
                        ))}
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="card p-6 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800">
              <h3 className="font-semibold text-amber-800 dark:text-amber-200 mb-2">Additional Information</h3>
              <ul className="text-sm text-amber-700 dark:text-amber-300 space-y-1">
                <li>Extra charge of ₱100 each for rice cooker, water heater, sound system</li>
                <li>+₱100 for extra foam and bedsheet</li>
                <li>Day Tour: 8AM &ndash; 5PM | Night Tour: 5PM &ndash; 8AM</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}