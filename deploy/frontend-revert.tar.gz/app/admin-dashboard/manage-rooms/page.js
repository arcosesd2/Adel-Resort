'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Plus, Pencil, Trash2, ToggleLeft, ToggleRight, X, ImageIcon, Tag, DollarSign, FileText, Users, Settings, Star } from 'lucide-react'
import toast from 'react-hot-toast'
import useAuthStore from '@/store/authStore'
import api from '@/lib/api'
import { cloudinaryUrl } from '@/lib/cloudinary'

const ROOM_TYPES = [
  { value: 'cottage', label: 'Cottage' },
  { value: 'dos_andanas', label: 'Dos Andanas' },
  { value: 'lavender_house', label: 'Lavender House' },
  { value: 'ac_karaoke', label: 'Air-Conditioned Room' },
  { value: 'kubo', label: 'Kubo' },
  { value: 'function_hall', label: 'Function Hall' },
  { value: 'trapal_table', label: 'Trapal Table' },
]

const BOOKING_MODES = [
  { value: 'slot', label: 'Day/Night Slot' },
  { value: 'overnight', label: 'Overnight (Check-in 2PM / Check-out 12NN)' },
  { value: '24hr', label: '24-Hour (Check-in & Check-out same time next day)' },
]

const emptyForm = {
  name: '', room_type: 'cottage', booking_mode: 'slot', description: '', day_price: '', night_price: '',
  is_day_only: false, capacity: 2, max_rooms: 1, size_sqm: '', amenities: '', is_active: true, is_featured: false,
}

export default function AdminManageRoomsPage() {
  const { user } = useAuthStore()
  const router = useRouter()
  const [rooms, setRooms] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [submitting, setSubmitting] = useState(false)
  const formRef = useRef(null)

  useEffect(() => {
    if (!user) return
    if (!user.is_superadmin) { router.push('/admin-dashboard'); return }
    fetchRooms()
  }, [user])

  const fetchRooms = async () => {
    try {
      const { data } = await api.get('/rooms/admin/')
      setRooms(data)
    } catch { toast.error('Failed to load rooms') }
    finally { setLoading(false) }
  }

  const openCreate = () => {
    setEditing(null)
    setForm(emptyForm)
    setShowForm(true)
    setTimeout(() => formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
  }

  const openEdit = (room) => {
    setEditing(room)
    setForm({
      name: room.name, room_type: room.room_type, booking_mode: room.booking_mode, description: room.description,
      day_price: room.day_price, night_price: room.night_price || '',
      is_day_only: room.is_day_only, capacity: room.capacity, max_rooms: room.max_rooms,
      size_sqm: room.size_sqm || '', amenities: (room.amenities || []).join(', '), is_active: room.is_active,
      is_featured: room.is_featured || false,
    })
    setShowForm(true)
    setTimeout(() => formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    const payload = {
      ...form,
      day_price: parseFloat(form.day_price),
      night_price: form.night_price ? parseFloat(form.night_price) : null,
      capacity: parseInt(form.capacity),
      max_rooms: parseInt(form.max_rooms),
      size_sqm: form.size_sqm ? parseInt(form.size_sqm) : null,
      amenities: form.amenities ? form.amenities.split(',').map(a => a.trim()).filter(Boolean) : [],
    }

    try {
      if (editing) {
        const { data } = await api.patch(`/rooms/admin/${editing.id}/`, payload)
        setRooms(prev => prev.map(r => r.id === editing.id ? data : r))
        toast.success('Room updated')
      } else {
        const { data } = await api.post('/rooms/admin/create/', payload)
        setRooms(prev => [...prev, data])
        toast.success('Room created')
      }
      setShowForm(false)
    } catch (err) {
      const errors = err.response?.data
      if (errors && typeof errors === 'object') {
        const msg = Object.entries(errors).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : v}`).join('\n')
        toast.error(msg)
      } else {
        toast.error('Failed to save')
      }
    } finally { setSubmitting(false) }
  }

  const handleDeactivate = async (room) => {
    if (!confirm(`Deactivate "${room.name}"? It will be hidden from the public.`)) return
    try {
      await api.delete(`/rooms/admin/${room.id}/`)
      setRooms(prev => prev.map(r => r.id === room.id ? { ...r, is_active: false } : r))
      toast.success('Room deactivated')
    } catch { toast.error('Failed to deactivate') }
  }

  const toggleActive = async (room) => {
    try {
      const { data } = await api.patch(`/rooms/admin/${room.id}/`, { is_active: !room.is_active })
      setRooms(prev => prev.map(r => r.id === room.id ? data : r))
      toast.success(data.is_active ? 'Room activated' : 'Room deactivated')
    } catch { toast.error('Failed to update') }
  }

  if (loading) return <div className="min-h-screen pt-24 flex items-center justify-center"><div className="spinner" /></div>

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link href="/admin-dashboard" className="text-gray-400 hover:text-gray-600"><ArrowLeft size={20} /></Link>
            <h1 className="font-serif text-2xl font-bold text-gray-900">Manage Rooms</h1>
          </div>
          <button onClick={openCreate} className="btn-primary text-sm flex items-center gap-2"><Plus size={16} /> Add Room</button>
        </div>

        {showForm && (
          <div ref={formRef} className="card mb-8 border-2 border-ocean-200">
            <div className="flex items-center justify-between px-6 py-4 bg-ocean-50 border-b border-ocean-200 rounded-t-lg">
              <div className="flex items-center gap-2">
                <Pencil size={18} className="text-ocean-600" />
                <h2 className="font-semibold text-lg text-ocean-800">{editing ? `Edit Room: ${editing.name}` : 'Create New Room'}</h2>
              </div>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600 transition-colors"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Basic Info */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <FileText size={16} className="text-ocean-500" />
                  <h3 className="font-medium text-gray-700">Basic Info</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-1">
                    <label className="label">Name</label>
                    <input type="text" className="input" required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Room name" />
                  </div>
                  <div>
                    <label className="label">Room Type</label>
                    <select className="input" value={form.room_type} onChange={e => setForm(f => ({ ...f, room_type: e.target.value }))}>
                      {ROOM_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="label">Booking Mode</label>
                    <select className="input" value={form.booking_mode} onChange={e => {
                      const mode = e.target.value
                      setForm(f => ({ ...f, booking_mode: mode, is_day_only: mode !== 'slot' ? false : f.is_day_only, night_price: mode !== 'slot' ? '' : f.night_price }))
                    }}>
                      {BOOKING_MODES.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="label">Description</label>
                <textarea className="input min-h-[80px]" required value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Describe the room..." />
              </div>

              {/* Pricing */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign size={16} className="text-ocean-500" />
                  <h3 className="font-medium text-gray-700">Pricing</h3>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div>
                    <label className="label">{form.booking_mode === 'overnight' ? 'Nightly Rate' : form.booking_mode === '24hr' ? 'Daily Rate (24hr)' : 'Day Price'}</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">₱</span>
                      <input type="number" step="0.01" className="input pl-7" required value={form.day_price} onChange={e => setForm(f => ({ ...f, day_price: e.target.value }))} />
                    </div>
                  </div>
                  {form.booking_mode === 'slot' && (
                    <div>
                      <label className="label">Night Price</label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">₱</span>
                        <input type="number" step="0.01" className="input pl-7" placeholder="Optional" value={form.night_price} onChange={e => setForm(f => ({ ...f, night_price: e.target.value }))} />
                      </div>
                    </div>
                  )}
                  <div>
                    <label className="label">Capacity (pax)</label>
                    <input type="number" className="input" required value={form.capacity} onChange={e => setForm(f => ({ ...f, capacity: e.target.value }))} />
                  </div>
                  <div>
                    <label className="label">Max Units</label>
                    <input type="number" className="input" required value={form.max_rooms} onChange={e => setForm(f => ({ ...f, max_rooms: e.target.value }))} />
                  </div>
                </div>
              </div>

              {/* Details */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Tag size={16} className="text-ocean-500" />
                  <h3 className="font-medium text-gray-700">Details</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Size (sqm)</label>
                    <input type="number" className="input" placeholder="Optional" value={form.size_sqm} onChange={e => setForm(f => ({ ...f, size_sqm: e.target.value }))} />
                  </div>
                  <div>
                    <label className="label">Amenities (comma-separated)</label>
                    <input type="text" className="input" placeholder="e.g. WiFi, AC, TV" value={form.amenities} onChange={e => setForm(f => ({ ...f, amenities: e.target.value }))} />
                  </div>
                </div>
              </div>

              {/* Settings */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Settings size={16} className="text-ocean-500" />
                  <h3 className="font-medium text-gray-700">Settings</h3>
                </div>
                <div className="flex items-center gap-6">
                  {form.booking_mode === 'slot' && (
                    <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-ocean-600 focus:ring-ocean-500" checked={form.is_day_only} onChange={e => setForm(f => ({ ...f, is_day_only: e.target.checked }))} />
                      Day tour only
                    </label>
                  )}
                  <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-ocean-600 focus:ring-ocean-500" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} />
                    Active (visible to public)
                  </label>
                  <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-ocean-600 focus:ring-ocean-500" checked={form.is_featured} onChange={e => setForm(f => ({ ...f, is_featured: e.target.checked }))} />
                    Featured on homepage
                  </label>
                </div>
              </div>

              {/* Submit */}
              <div className="flex items-center gap-3 pt-2">
                <button type="submit" disabled={submitting} className="btn-primary px-8">
                  {submitting ? 'Saving...' : editing ? 'Update Room' : 'Create Room'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="btn-outline px-6">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {rooms.length === 0 ? (
          <div className="card p-12 text-center text-gray-500">No rooms yet.</div>
        ) : (
          <div className="grid gap-4">
            {rooms.map(room => (
              <div key={room.id} className={`card overflow-hidden ${!room.is_active ? 'opacity-60' : ''}`}>
                <div className="flex items-start gap-4 p-5">
                  {room.primary_image ? (
                    <img src={cloudinaryUrl(room.primary_image, { width: 200 })} alt={room.name} className="w-24 h-24 rounded-xl object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-24 h-24 rounded-xl bg-gray-100 flex items-center justify-center flex-shrink-0"><ImageIcon size={28} className="text-gray-300" /></div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 text-lg truncate">{room.name}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${room.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {room.is_active ? 'Active' : 'Inactive'}
                      </span>
                      {room.is_featured && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-yellow-100 text-yellow-700 flex items-center gap-1">
                          <Star size={10} className="fill-yellow-500" /> Featured
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mb-2">
                      {room.room_type_display} &middot; {room.capacity} pax &middot; {room.max_rooms} unit(s)
                    </p>
                    <p className="text-xs font-medium text-ocean-600 bg-ocean-50 inline-block px-2 py-1 rounded-md mb-3">
                      {room.booking_mode === 'slot' ? 'Day/Night' : room.booking_mode === 'overnight' ? 'Overnight' : '24-Hour'}
                      {' — '}
                      {room.booking_mode === 'overnight' ? '₱' + Number(room.day_price).toLocaleString() + '/night' : room.booking_mode === '24hr' ? '₱' + Number(room.day_price).toLocaleString() + '/day' : <>Day: ₱{Number(room.day_price).toLocaleString()}{room.night_price && <> · Night: ₱{Number(room.night_price).toLocaleString()}</>}</>}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <button onClick={() => openEdit(room)} className="inline-flex items-center gap-1.5 text-sm font-medium text-white bg-ocean-600 hover:bg-ocean-700 px-3 py-1.5 rounded-lg transition-colors">
                        <Pencil size={14} /> Edit Room
                      </button>
                      <Link href={`/admin-dashboard/rooms?room=${room.id}`} className="inline-flex items-center gap-1.5 text-sm font-medium text-ocean-600 bg-ocean-50 hover:bg-ocean-100 px-3 py-1.5 rounded-lg transition-colors">
                        <ImageIcon size={14} /> Photos
                      </Link>
                      <button onClick={() => toggleActive(room)} className="inline-flex items-center gap-1.5 text-sm font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-lg transition-colors">
                        {room.is_active ? <><ToggleRight size={14} /> Active</> : <><ToggleLeft size={14} /> Inactive</>}
                      </button>
                      {room.is_active && (
                        <button onClick={() => handleDeactivate(room)} className="inline-flex items-center gap-1.5 text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors">
                          <Trash2 size={14} /> Remove
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
